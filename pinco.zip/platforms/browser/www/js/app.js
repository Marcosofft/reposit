var app = angular.module('myApp', []);

// here we define our unique filter
app.filter('unique', function() {
   // we will return a function which will take in a collection
   // and a keyname
   return function(collection, keyname) {
      // we define our output and keys array;
      var output = [], 
          keys = [];

      // we utilize angular's foreach function
      // this takes in our original collection and an iterator function
      
      
      
      angular.forEach(collection, function(item) {
          // we check to see whether our object exists
          var key = item[keyname];
          if (key != undefined){
            key =key[0];
          // if it's not already part of our keys array
          if(keys.indexOf(key) === -1) {
              // add it to our keys array
              keys.push(key); 
              // push this item to our final output array
              output.push(item);
          }
      }
      });
      // return our array which should be devoid of
      // any duplicates
      return output;
   };
});


app.factory('Socket', ['$rootScope', function($rootScope) {
    //var url = window.location.hostname;
    var url = '10.1.5.59';
    var socket = io.connect(url+":5000/", {
        'query': 'token='
    });
    var Socket = {
        connect: function() {
            socket.connect();
        },
        on: function (eventName, callback) {
            socket.on(eventName, function () {
                var args = arguments;
                $rootScope.$apply(function () {
                    callback.apply(socket, args);
                });
            });
        },
        emit: function (eventName, data, callback) {
            socket.emit(eventName, data, function () {
                var args = arguments;
                $rootScope.$apply(function () {
                    if (callback) {
                        callback.apply(socket, args);
                    }
                });
            });
        }
    };
    return Socket;
}])

  
app.controller('mainController', ['$scope', 'Socket' , function($scope, Socket) {
    $scope.name = "abc";
    $scope.cambia = function(val) {
        //$scope.name = val;
        Socket.emit('test', val);
    };
    Socket.on('testR' , function (res){
        $scope.name = res;
        //console.log(res);
        //alert(res);
    });
    
    Socket.on('hw' , function (res){
        $scope.hwname = res;
        //console.log(res);
        //alert(res);
    });
    
}]);
 
